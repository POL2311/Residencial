// guardia/js/autos.js
(function () {
  window.GuardiaViews = window.GuardiaViews || {};

  window.GuardiaViews.autos = function ({ API, fetchJSON, openModal, closeModal, escapeHtml }) {
    const root = document.getElementById('autosView');
    if (!root) return;

    const els = {
      list: document.getElementById('autosList'),
      frm: document.getElementById('frmAutosFilter'),
      fPlacas: document.getElementById('fPlacas'),
      fModelo: document.getElementById('fModelo'),
      btnNew: document.getElementById('btnNuevoAuto'),
    };

    // ---------------- helpers UI ----------------
    function formRow(label, inputHtml) {
      return `
        <div class="rounded-xl bg-slate-50 px-3 py-2 border border-slate-200">
          <div class="text-xs text-slate-500">${label}</div>
          <div class="mt-1">${inputHtml}</div>
        </div>
      `;
    }

    function buildDatalist(id, items, mapToOption) {
      return `
        <datalist id="${id}">
          ${items.map(mapToOption).join('')}
        </datalist>
      `;
    }

    function parseIdFromPick(value) {
      // Espera "... (#123)"
      const m = String(value || '').match(/\(#(\d+)\)\s*$/);
      return m ? m[1] : '';
    }

    // caches de catálogo (para resolver por clave/nombre)
    let cacheUnidades = [];
    let cacheProps = [];

    async function safeFetch(url, tries = 2) {
      let lastErr;
      for (let i = 0; i < tries; i++) {
        try {
          return await fetchJSON(url);
        } catch (e) {
          lastErr = e;
        }
      }
      throw lastErr;
    }

    async function getUnidades(q = '') {
      const qs = new URLSearchParams();
      if (q) qs.set('q', q);
      const json = await safeFetch(`${API}unidades.php?${qs.toString()}`, 2);
      const items = json.data?.items || [];
      if (!q) cacheUnidades = items; // cachea la carga completa
      return items;
    }

    async function getPropietarios(q = '') {
      const qs = new URLSearchParams();
      if (q) qs.set('q', q);
      const json = await safeFetch(`${API}propietarios.php?${qs.toString()}`, 2);
      const items = json.data?.items || [];
      if (!q) cacheProps = items;
      return items;
    }

    function findUnidadIdByText(text) {
      const t = String(text || '').trim().toLowerCase();
      if (!t) return '';
      // match por clave exacta (C-100) o contiene
      const exact = cacheUnidades.find(u => String(u.clave || '').trim().toLowerCase() === t);
      if (exact) return String(exact.id);
      const contains = cacheUnidades.find(u => String(u.clave || '').toLowerCase().includes(t));
      return contains ? String(contains.id) : '';
    }

    function findPropIdByText(text) {
      const t = String(text || '').trim().toLowerCase();
      if (!t) return '';
      // match por nombre/email contiene
      const hit = cacheProps.find(p =>
        String(p.name || '').toLowerCase().includes(t) ||
        String(p.email || '').toLowerCase().includes(t)
      );
      return hit ? String(hit.id) : '';
    }

    // ---------------- render list ----------------
    function render(items) {
      if (!els.list) return;
      if (!items || items.length === 0) {
        els.list.innerHTML = `<div class="text-xs text-slate-500">No hay autos con esos filtros.</div>`;
        return;
      }

      els.list.innerHTML = `
        <div class="space-y-2">
          ${items.map(a => `
            <button type="button"
                    class="w-full text-left rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 hover:bg-slate-100"
                    data-auto='${escapeHtml(JSON.stringify(a))}'>
              <div class="flex items-center justify-between">
                <div class="font-semibold text-slate-800">${escapeHtml(a.placas || '—')}</div>
                <div class="text-[11px] text-slate-500">${escapeHtml(a.unidad_clave || '—')}</div>
              </div>
              <div class="text-[11px] text-slate-600 mt-1">
                ${escapeHtml(a.modelo || '—')} · ${escapeHtml(a.color || '—')} · ${escapeHtml(a.propietario_nombre || '—')}
              </div>
            </button>
          `).join('')}
        </div>
      `;

      els.list.querySelectorAll('button[data-auto]').forEach(btn => {
        btn.addEventListener('click', () => {
          const a = JSON.parse(btn.getAttribute('data-auto') || '{}');
          openEditModal(a);
        });
      });
    }

    // ---------------- load list ----------------
    async function load() {
      if (!els.list) return;
      els.list.textContent = 'Cargando…';

      const placas = (els.fPlacas?.value || '').trim();
      const modelo = (els.fModelo?.value || '').trim();

      const q = new URLSearchParams();
      q.set('action', 'list');
      if (placas) q.set('placas', placas);
      if (modelo) q.set('modelo', modelo);

      try {
        const json = await fetchJSON(`${API}autos.php?${q.toString()}`);
        render(json.data?.items || []);
      } catch (e) {
        els.list.innerHTML = `<div class="text-xs text-rose-700">Error: ${escapeHtml(e.message || String(e))}</div>`;
      }
    }

    // --------- live datalist updater (pro) ---------
    function wireLiveDatalist(inputEl, datalistEl, type) {
      // type: 'unidades' | 'props'
      let timer = null;

      async function refresh(q) {
        try {
          const items = type === 'unidades' ? await getUnidades(q) : await getPropietarios(q);

          datalistEl.innerHTML = items.map(it => {
            if (type === 'unidades') {
              const label = `${it.clave || '—'}${it.tipo ? ' · ' + it.tipo : ''} (#${it.id})`;
              return `<option value="${escapeHtml(label)}"></option>`;
            } else {
              const label = `${it.name || '—'}${it.email ? ' · ' + it.email : ''} (#${it.id})`;
              return `<option value="${escapeHtml(label)}"></option>`;
            }
          }).join('');
        } catch (e) {
          // no truena el modal
        }
      }

      inputEl.addEventListener('input', () => {
        const v = inputEl.value || '';
        clearTimeout(timer);
        timer = setTimeout(() => refresh(v.trim()), 250);
      });

      // primera carga (ya debe venir precargada)
    }

    // ---------------- create modal ----------------
    async function openCreateModal() {
    let unidades = [];
    let propietarios = [];
    let catalogOk = true;

    try {
        [unidades, propietarios] = await Promise.all([getUnidades(''), getPropietarios('')]);
    } catch (e) {
        catalogOk = false;
    }

    openModal('Nuevo auto', `
        <form id="frmAutoCreate" class="space-y-2">

        ${!catalogOk ? `
            <div class="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
            No pude cargar el catálogo de Unidades/Propietarios. Revisa endpoints.
            (Aún puedes guardar, pero sin lista.)
            </div>
        ` : ''}

        ${formRow('Placas *',
            `<input name="placas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    placeholder="ABC123" required />`
        )}

        ${formRow('Modelo',
            `<input name="modelo" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    placeholder="R3 YAMAHA" />`
        )}

        ${formRow('Color',
            `<input name="color" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    placeholder="AZUL" />`
        )}

        ${formRow('Unidad',
            `
            <select name="unidad_id" id="unidadSelectCreate"
                    class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white">
            <option value="">Selecciona una unidad…</option>
            ${(unidades || []).map(u => {
                const label =
                `${u.clave || '—'}${u.tipo ? ' · ' + u.tipo : ''}` +
                `${u.torre ? ' · ' + u.torre : ''}` +
                `${u.nivel ? ' · nivel ' + u.nivel : ''}` +
                ` (#${u.id})`;
                return `<option value="${escapeHtml(String(u.id))}">${escapeHtml(label)}</option>`;
            }).join('')}
            </select>
            <div class="text-[11px] text-slate-500 mt-1">Selecciona una unidad existente.</div>
            `
        )}

        ${formRow('Propietario',
            `
            <select name="propietario_user_id" id="propSelectCreate"
                    class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white">
            <option value="">Selecciona un propietario…</option>
            ${(propietarios || []).map(p => {
                const label = `${p.name || '—'}${p.email ? ' · ' + p.email : ''} (#${p.id})`;
                return `<option value="${escapeHtml(String(p.id))}">${escapeHtml(label)}</option>`;
            }).join('')}
            </select>
            <div class="text-[11px] text-slate-500 mt-1">Selecciona un usuario existente.</div>
            `
        )}

        ${formRow('Notas',
            `<textarea name="notas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                    rows="3" placeholder="Opcional"></textarea>`
        )}

        <div class="mt-3 flex justify-end gap-2">
            <button type="button" class="rounded-xl border border-slate-200 px-4 py-2 text-sm" id="btnCancelAutoCreate">Cancelar</button>
            <button type="submit" class="rounded-xl bg-[#4E7287] text-white px-4 py-2 text-sm shadow">Guardar</button>
        </div>

        <div id="autoCreateMsg" class="text-xs mt-2"></div>
        </form>
    `);

    document.getElementById('btnCancelAutoCreate')?.addEventListener('click', closeModal);

    const frm = document.getElementById('frmAutoCreate');
    frm?.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const msg = document.getElementById('autoCreateMsg');
        if (msg) msg.textContent = 'Guardando…';

        const fd = new FormData(frm);
        fd.set('action', 'create');

        // si no eligió, no lo mandes
        if (!fd.get('unidad_id')) fd.delete('unidad_id');
        if (!fd.get('propietario_user_id')) fd.delete('propietario_user_id');

        try {
        await fetchJSON(`${API}autos.php`, { method: 'POST', body: fd });
        if (msg) msg.textContent = '';
        closeModal();
        load();
        } catch (e) {
        if (msg) msg.innerHTML = `<span class="text-rose-700">Error: ${escapeHtml(e.message || String(e))}</span>`;
        }
    });
    }


    // ---------------- edit modal ----------------
async function openEditModal(a) {
  let unidades = [];
  let propietarios = [];
  let catalogOk = true;

  try {
    [unidades, propietarios] = await Promise.all([getUnidades(''), getPropietarios('')]);
  } catch (e) {
    catalogOk = false;
  }

  openModal('Auto', `
    <form id="frmAutoEdit" class="space-y-2">
      <input type="hidden" name="auto_id" value="${escapeHtml(String(a.id || ''))}" />

      ${!catalogOk ? `
        <div class="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
          No pude cargar el catálogo de Unidades/Propietarios. Revisa endpoints.
        </div>
      ` : ''}

      ${formRow('Placas *',
        `<input name="placas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                value="${escapeHtml(a.placas || '')}" required />`
      )}

      ${formRow('Modelo',
        `<input name="modelo" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                value="${escapeHtml(a.modelo || '')}" />`
      )}

      ${formRow('Color',
        `<input name="color" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                value="${escapeHtml(a.color || '')}" />`
      )}

      ${formRow('Unidad',
        `
        <select name="unidad_id" id="unidadSelectEdit"
                class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white">
          <option value="">Sin unidad</option>
          ${(unidades || []).map(u => {
            const label =
              `${u.clave || '—'}${u.tipo ? ' · ' + u.tipo : ''}` +
              `${u.torre ? ' · ' + u.torre : ''}` +
              `${u.nivel ? ' · nivel ' + u.nivel : ''}` +
              ` (#${u.id})`;
            const selected = String(u.id) === String(a.unidad_id ?? '') ? 'selected' : '';
            return `<option value="${escapeHtml(String(u.id))}" ${selected}>${escapeHtml(label)}</option>`;
          }).join('')}
        </select>
        `
      )}

      ${formRow('Propietario',
        `
        <select name="propietario_user_id" id="propSelectEdit"
                class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white">
          <option value="">Sin propietario</option>
          ${(propietarios || []).map(p => {
            const label = `${p.name || '—'}${p.email ? ' · ' + p.email : ''} (#${p.id})`;
            const selected = String(p.id) === String(a.propietario_user_id ?? '') ? 'selected' : '';
            return `<option value="${escapeHtml(String(p.id))}" ${selected}>${escapeHtml(label)}</option>`;
          }).join('')}
        </select>
        `
      )}

      ${formRow('Notas',
        `<textarea name="notas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                   rows="3">${escapeHtml(a.notas || '')}</textarea>`
      )}

      <div class="mt-3 flex justify-between gap-2">
        <button type="button" class="rounded-xl border border-rose-200 text-rose-700 px-4 py-2 text-sm" id="btnAutoDelete">
          Desactivar
        </button>

        <div class="flex gap-2">
          <button type="button" class="rounded-xl border border-slate-200 px-4 py-2 text-sm" id="btnAutoCancel">Cerrar</button>
          <button type="submit" class="rounded-xl bg-[#4E7287] text-white px-4 py-2 text-sm shadow">Guardar cambios</button>
        </div>
      </div>

      <div id="autoEditMsg" class="text-xs mt-2"></div>
    </form>
  `);

  document.getElementById('btnAutoCancel')?.addEventListener('click', closeModal);

  document.getElementById('btnAutoDelete')?.addEventListener('click', async () => {
    const ok = confirm('¿Desactivar este auto? (ya no saldrá en la lista)');
    if (!ok) return;

    const fd = new FormData();
    fd.set('action', 'delete');
    fd.set('auto_id', String(a.id));

    const msg = document.getElementById('autoEditMsg');
    if (msg) msg.textContent = 'Desactivando…';

    try {
      await fetchJSON(`${API}autos.php`, { method: 'POST', body: fd });
      if (msg) msg.textContent = '';
      closeModal();
      load();
    } catch (e) {
      if (msg) msg.innerHTML = `<span class="text-rose-700">Error: ${escapeHtml(e.message || String(e))}</span>`;
    }
  });

  const frm = document.getElementById('frmAutoEdit');
  frm?.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const msg = document.getElementById('autoEditMsg');
    if (msg) msg.textContent = 'Guardando…';

    const fd = new FormData(frm);
    fd.set('action', 'update');

    // si no eligió, no lo mandes
    if (!fd.get('unidad_id')) fd.delete('unidad_id');
    if (!fd.get('propietario_user_id')) fd.delete('propietario_user_id');

    try {
      await fetchJSON(`${API}autos.php`, { method: 'POST', body: fd });
      if (msg) msg.textContent = '';
      closeModal();
      load();
    } catch (e) {
      if (msg) msg.innerHTML = `<span class="text-rose-700">Error: ${escapeHtml(e.message || String(e))}</span>`;
    }
  });
}


    // ---------------- events ----------------
    els.frm?.addEventListener('submit', (ev) => {
      ev.preventDefault();
      load();
    });

    els.btnNew?.addEventListener('click', openCreateModal);

    load();
  };
})();
