// guardia/js/autos.js
(function () {
  window.GuardiaViews = window.GuardiaViews || {};

  window.GuardiaViews.autos = function ({ API, fetchJSON, openModal, closeModal, escapeHtml }) {
    const root = document.getElementById('autosView');
    if (!root) return;

    const els = {
      list: document.getElementById('autosList'),
      frm: document.getElementById('frmAutosFilter'),
      fPlacas: document.getElementById('fPlacas'),
      fModelo: document.getElementById('fModelo'),
      btnNew: document.getElementById('btnNuevoAuto'),
    };

    let lastItems = [];

    function render(items) {
      lastItems = Array.isArray(items) ? items : [];
      if (!els.list) return;

      if (!lastItems.length) {
        els.list.innerHTML = `<div class="text-xs text-slate-500">No hay autos con esos filtros.</div>`;
        return;
      }

      els.list.innerHTML = `
        <div class="space-y-2">
          ${lastItems.map(a => `
            <button type="button"
                    class="w-full text-left rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 hover:bg-slate-100"
                    data-auto='${escapeHtml(JSON.stringify(a))}'>
              <div class="flex items-center justify-between">
                <div class="font-semibold text-slate-800">${escapeHtml(a.placas || '—')}</div>
                <div class="text-[11px] text-slate-500">${escapeHtml(a.unidad_clave || '—')}</div>
              </div>
              <div class="text-[11px] text-slate-600 mt-1">
                ${escapeHtml(a.modelo || '—')} · ${escapeHtml(a.color || '—')} · ${escapeHtml(a.propietario_nombre || '—')}
              </div>
            </button>
          `).join('')}
        </div>
      `;

      els.list.querySelectorAll('button[data-auto]').forEach(btn => {
        btn.addEventListener('click', () => {
          const a = JSON.parse(btn.getAttribute('data-auto') || '{}');
          openEditModal(a);
        });
      });
    }

    async function load() {
      if (!els.list) return;
      els.list.textContent = 'Cargando…';

      const placas = (els.fPlacas?.value || '').trim();
      const modelo = (els.fModelo?.value || '').trim();

      const q = new URLSearchParams();
      q.set('action', 'list');
      if (placas) q.set('placas', placas);
      if (modelo) q.set('modelo', modelo);

      try {
        const json = await fetchJSON(`${API}autos.php?${q.toString()}`);
        render(json.data?.items || []);
      } catch (e) {
        els.list.innerHTML = `<div class="text-xs text-rose-700">Error: ${escapeHtml(e.message || String(e))}</div>`;
      }
    }

    function formRow(label, inputHtml) {
      return `
        <div class="rounded-xl bg-slate-50 px-3 py-2 border border-slate-200">
          <div class="text-xs text-slate-500">${label}</div>
          <div class="mt-1">${inputHtml}</div>
        </div>
      `;
    }

    function openCreateModal() {
      openModal('Nuevo auto', `
        <form id="frmAutoCreate" class="space-y-2">
          ${formRow('Placas *', `<input name="placas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" placeholder="ABC123" required />`)}
          ${formRow('Modelo', `<input name="modelo" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" placeholder="R3 YAMAHA" />`)}
          ${formRow('Color', `<input name="color" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" placeholder="AZUL" />`)}
          ${formRow('Unidad ID (opcional)', `<input name="unidad_id" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" placeholder="1" />`)}
          ${formRow('Propietario user_id (opcional)', `<input name="propietario_user_id" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" placeholder="4" />`)}
          ${formRow('Notas', `<textarea name="notas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" rows="3" placeholder="Opcional"></textarea>`)}

          <div class="mt-3 flex justify-end gap-2">
            <button type="button" class="rounded-xl border border-slate-200 px-4 py-2 text-sm" id="btnCancelAutoCreate">Cancelar</button>
            <button type="submit" class="rounded-xl bg-[#4E7287] text-white px-4 py-2 text-sm shadow">Guardar</button>
          </div>

          <div id="autoCreateMsg" class="text-xs mt-2"></div>
        </form>
      `);

      document.getElementById('btnCancelAutoCreate')?.addEventListener('click', closeModal);

      const frm = document.getElementById('frmAutoCreate');
      frm?.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const msg = document.getElementById('autoCreateMsg');
        if (msg) msg.textContent = 'Guardando…';

        const fd = new FormData(frm);
        fd.set('action', 'create');

        try {
          await fetchJSON(`${API}autos.php`, { method: 'POST', body: fd });
          if (msg) msg.textContent = '';
          closeModal();
          load();
        } catch (e) {
          if (msg) msg.innerHTML = `<span class="text-rose-700">Error: ${escapeHtml(e.message || String(e))}</span>`;
        }
      });
    }

    function openEditModal(a) {
      openModal('Auto', `
        <form id="frmAutoEdit" class="space-y-2">
          <input type="hidden" name="auto_id" value="${escapeHtml(String(a.id || ''))}" />
          ${formRow('Placas *', `<input name="placas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" value="${escapeHtml(a.placas || '')}" required />`)}
          ${formRow('Modelo', `<input name="modelo" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" value="${escapeHtml(a.modelo || '')}" />`)}
          ${formRow('Color', `<input name="color" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" value="${escapeHtml(a.color || '')}" />`)}
          ${formRow('Unidad ID', `<input name="unidad_id" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" value="${escapeHtml(String(a.unidad_id ?? ''))}" />`)}
          ${formRow('Propietario user_id', `<input name="propietario_user_id" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" value="${escapeHtml(String(a.propietario_user_id ?? ''))}" />`)}
          ${formRow('Notas', `<textarea name="notas" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm" rows="3">${escapeHtml(a.notas || '')}</textarea>`)}

          <div class="mt-3 flex justify-between gap-2">
            <button type="button" class="rounded-xl border border-rose-200 text-rose-700 px-4 py-2 text-sm" id="btnAutoDelete">
              Desactivar
            </button>

            <div class="flex gap-2">
              <button type="button" class="rounded-xl border border-slate-200 px-4 py-2 text-sm" id="btnAutoCancel">Cerrar</button>
              <button type="submit" class="rounded-xl bg-[#4E7287] text-white px-4 py-2 text-sm shadow">Guardar cambios</button>
            </div>
          </div>

          <div id="autoEditMsg" class="text-xs mt-2"></div>
        </form>
      `);

      document.getElementById('btnAutoCancel')?.addEventListener('click', closeModal);

      document.getElementById('btnAutoDelete')?.addEventListener('click', async () => {
        const ok = confirm('¿Desactivar este auto? (ya no saldrá en la lista)');
        if (!ok) return;

        const fd = new FormData();
        fd.set('action', 'delete');
        fd.set('auto_id', String(a.id));

        const msg = document.getElementById('autoEditMsg');
        if (msg) msg.textContent = 'Desactivando…';

        try {
          await fetchJSON(`${API}autos.php`, { method: 'POST', body: fd });
          if (msg) msg.textContent = '';
          closeModal();
          load();
        } catch (e) {
          if (msg) msg.innerHTML = `<span class="text-rose-700">Error: ${escapeHtml(e.message || String(e))}</span>`;
        }
      });

      const frm = document.getElementById('frmAutoEdit');
      frm?.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const msg = document.getElementById('autoEditMsg');
        if (msg) msg.textContent = 'Guardando…';

        const fd = new FormData(frm);
        fd.set('action', 'update');

        try {
          await fetchJSON(`${API}autos.php`, { method: 'POST', body: fd });
          if (msg) msg.textContent = '';
          closeModal();
          load();
        } catch (e) {
          if (msg) msg.innerHTML = `<span class="text-rose-700">Error: ${escapeHtml(e.message || String(e))}</span>`;
        }
      });
    }

    els.frm?.addEventListener('submit', (ev) => {
      ev.preventDefault();
      load();
    });

    els.btnNew?.addEventListener('click', openCreateModal);

    load();
  };
})();
