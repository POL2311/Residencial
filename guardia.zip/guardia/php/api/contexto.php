<?php
// guardia/php/api/contexto.php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/../../../config/auth.php';
require_once __DIR__ . '/../../../config/config.php';

require_login();
require_role(['guardia','super_admin']);

$sessionUser = current_user();
$uid = (int)($sessionUser['id'] ?? 0);

function json_out(bool $ok, array $extra = []): void {
  echo json_encode(array_merge(['ok' => $ok], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}

function clean_str(?string $v): string {
  $v = (string)($v ?? '');
  $v = trim(preg_replace('/\s+/', ' ', $v));
  return $v;
}

function join_parts(array $parts, string $sep = ' · '): string {
  $out = [];
  foreach ($parts as $p) {
    $p = clean_str((string)$p);
    if ($p !== '') $out[] = $p;
  }
  return implode($sep, $out);
}

try {
  // 1) usuario fresco
  $stmtU = $pdo->prepare("SELECT id, name, email, telefono, role FROM users WHERE id = :id LIMIT 1");
  $stmtU->execute(['id' => $uid]);
  $user = $stmtU->fetch(PDO::FETCH_ASSOC);
  if (!$user) json_out(false, ['error' => 'Usuario no encontrado.']);

  // 2) residencial asignado al guardia
  $stmtR = $pdo->prepare("
    SELECT
      r.id AS residencial_id,
      r.nombre AS residencial_nombre,
      r.calle  AS res_calle,
      r.numero_exterior AS res_numero_exterior,
      r.numero_interior AS res_numero_interior,
      r.colonia AS res_colonia,
      r.ciudad  AS res_ciudad,
      r.estado  AS res_estado,
      r.codigo_postal AS res_codigo_postal
    FROM usuarios_residenciales ur
    JOIN residenciales r ON r.id = ur.residencial_id
    WHERE ur.user_id = :user_id
    ORDER BY ur.es_principal DESC, ur.created_at ASC
    LIMIT 1
  ");
  $stmtR->execute(['user_id' => $uid]);
  $ctx = $stmtR->fetch(PDO::FETCH_ASSOC) ?: null;

  if (!$ctx) {
    json_out(false, ['error' => 'Tu cuenta de guardia no está asociada a un residencial.']);
  }

  $resName = clean_str($ctx['residencial_nombre'] ?? '');
  $header_line = $resName !== '' ? ("Residencial: " . $resName) : '—';

  $line1 = join_parts([
    $ctx['res_calle'] ?? '',
    $ctx['res_numero_exterior'] ?? '',
    ($ctx['res_numero_interior'] ?? '') !== '' ? ('Int ' . $ctx['res_numero_interior']) : ''
  ], ' ');

  $line2 = join_parts([
    $ctx['res_colonia'] ?? '',
    $ctx['res_ciudad'] ?? '',
    $ctx['res_estado'] ?? '',
    ($ctx['res_codigo_postal'] ?? '') !== '' ? ('CP ' . $ctx['res_codigo_postal']) : ''
  ], ', ');

  $residencial_direccion = join_parts([$line1, $line2], ' · ');
  if ($residencial_direccion === '') $residencial_direccion = null;

  json_out(true, [
    'data' => [
      'user' => $user,
      'ctx'  => $ctx,
      'direccion' => $header_line,      // compat
      'header_line' => $header_line,
      'residencial_direccion' => $residencial_direccion,
    ]
  ]);

} catch (Throwable $e) {
  json_out(false, ['error' => 'Error: ' . $e->getMessage()]);
}
