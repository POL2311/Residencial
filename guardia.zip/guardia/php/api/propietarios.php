<?php
// guardia/php/api/propietarios.php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require_once __DIR__ . '/../../../config/auth.php';
require_once __DIR__ . '/../../../config/config.php';

require_login();
require_role(['guardia', 'super_admin']);

$user = current_user();
$uid  = (int)($user['id'] ?? 0);

function json_out(bool $ok, array $extra = [], int $status = 200): void {
  http_response_code($status);
  echo json_encode(array_merge(['ok' => $ok], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}
function clean(string $v): string {
  return trim((string)preg_replace('/\s+/', ' ', $v));
}
function getGuardResidencialId(PDO $pdo, int $uid): int {
  $stmt = $pdo->prepare("
    SELECT ur.residencial_id
    FROM usuarios_residenciales ur
    WHERE ur.user_id = :uid
    ORDER BY ur.es_principal DESC, ur.created_at ASC
    LIMIT 1
  ");
  $stmt->execute(['uid' => $uid]);
  return (int)($stmt->fetchColumn() ?: 0);
}

$rid = getGuardResidencialId($pdo, $uid);
if ($rid <= 0) json_out(false, ['error' => 'Guardia sin residencial asignado.'], 403);

$q = clean((string)($_GET['q'] ?? ''));

$params = ['rid' => $rid];
$and = "";
if ($q !== '') {
  $and = " AND (u.name LIKE :q OR u.email LIKE :q)";
  $params['q'] = '%' . $q . '%';
}

$stmt = $pdo->prepare("
  SELECT DISTINCT u.id, u.name, u.email
  FROM usuarios_residenciales ur
  JOIN users u ON u.id = ur.user_id
  WHERE ur.residencial_id = :rid
  $and
  ORDER BY u.name ASC
  LIMIT 400
");
$stmt->execute($params);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

json_out(true, ['data' => ['items' => $items]]);
