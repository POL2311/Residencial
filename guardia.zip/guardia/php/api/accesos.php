<?php
// guardia/php/api/accesos.php
require_once __DIR__ . '/../../../config/config.php';
require_once __DIR__ . '/../../../config/auth.php';

require_login();
require_role(['guardia', 'super_admin']);

header('Content-Type: application/json; charset=utf-8');

function out(bool $ok, array $payload = [], int $status = 200): void {
  http_response_code($status);
  echo json_encode(array_merge(['ok' => $ok], $payload));
  exit;
}

function strv($v, int $max = 255): string {
  $s = trim((string)($v ?? ''));
  if (mb_strlen($s) > $max) $s = mb_substr($s, 0, $max);
  return $s;
}

function intv($v, int $default = 0): int {
  if ($v === null || $v === '') return $default;
  return (int)$v;
}

function get_residencial_id(PDO $pdo, array $user): int {
  $stmt = $pdo->prepare("
    SELECT ur.residencial_id
    FROM usuarios_residenciales ur
    WHERE ur.user_id = :uid
    ORDER BY ur.es_principal DESC, ur.created_at ASC
    LIMIT 1
  ");
  $stmt->execute(['uid' => (int)$user['id']]);
  $rid = $stmt->fetchColumn();
  if (!$rid) out(false, ['error' => 'Tu usuario guardia no está asignado a un residencial.'], 403);
  return (int)$rid;
}

function now_mx(): DateTime {
  // Ajusta si tu servidor ya está en MX y no quieres timezone fijo
  return new DateTime('now');
}

function time_in_range(?string $hDesde, ?string $hHasta, DateTime $now): bool {
  if (!$hDesde && !$hHasta) return true;
  $cur = $now->format('H:i:s');

  // Si solo hay desde
  if ($hDesde && !$hHasta) return $cur >= $hDesde;
  // Si solo hay hasta
  if (!$hDesde && $hHasta) return $cur <= $hHasta;

  // Ambos
  return ($cur >= $hDesde && $cur <= $hHasta);
}

$user = current_user();
$guardiaId = (int)$user['id'];
$residencialId = get_residencial_id($pdo, $user);

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

try {

  /**
   * ==========================
   * GET: LISTAR VISITAS (ACCESOS)
   * ==========================
   * /accesos.php?action=list
   *   &q= (busca por codigo/nombre/placa)
   *   &estado=pendiente|usado|vencido|cancelado
   *   &tipo=visita|servicio|trabajador_recurrente
   *   &from=YYYY-MM-DD
   *   &to=YYYY-MM-DD
   *   &limit=50&offset=0
   */
  if ($method === 'GET' && $action === 'list') {

    $limit  = max(1, min(200, intv($_GET['limit'] ?? 50, 50)));
    $offset = max(0, intv($_GET['offset'] ?? 0, 0));

    $q      = strv($_GET['q'] ?? '', 80);
    $estado = strv($_GET['estado'] ?? '', 20);
    $tipo   = strv($_GET['tipo'] ?? '', 40);

    $from   = strv($_GET['from'] ?? '', 10);
    $to     = strv($_GET['to'] ?? '', 10);

    $where = ["v.residencial_id = :rid"];
    $params = ['rid' => $residencialId];

    if ($q !== '') {
      $where[] = "(v.codigo_acceso LIKE :q OR v.nombre_visitante LIKE :q OR v.placa_vehiculo LIKE :q)";
      $params['q'] = "%{$q}%";
    }

    if ($estado !== '') {
      $allowedEstado = ['pendiente','usado','vencido','cancelado'];
      if (!in_array($estado, $allowedEstado, true)) {
        out(false, ['error' => 'estado inválido'], 422);
      }
      $where[] = "v.estado = :estado";
      $params['estado'] = $estado;
    }

    if ($tipo !== '') {
      $allowedTipo = ['visita','servicio','trabajador_recurrente'];
      if (!in_array($tipo, $allowedTipo, true)) {
        out(false, ['error' => 'tipo inválido'], 422);
      }
      $where[] = "v.tipo = :tipo";
      $params['tipo'] = $tipo;
    }

    if ($from !== '' && $to !== '') {
      $where[] = "(v.fecha_desde <= :to AND v.fecha_hasta >= :from)";
      $params['from'] = $from;
      $params['to']   = $to;
    } elseif ($from !== '') {
      $where[] = "v.fecha_hasta >= :from";
      $params['from'] = $from;
    } elseif ($to !== '') {
      $where[] = "v.fecha_desde <= :to";
      $params['to'] = $to;
    }

    $sql = "
      SELECT
        v.*,
        u.nombre AS unidad_nombre,
        r.name   AS residente_nombre
      FROM visitas v
      JOIN unidades u ON u.id = v.unidad_id
      JOIN users r    ON r.id = v.residente_id
      WHERE " . implode(" AND ", $where) . "
      ORDER BY v.created_at DESC
      LIMIT :lim OFFSET :off
    ";

    $stmt = $pdo->prepare($sql);
    foreach ($params as $k => $v) $stmt->bindValue(':' . $k, $v);
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $items = $stmt->fetchAll();

    out(true, [
      'items' => $items,
      'meta' => [
        'limit' => $limit,
        'offset' => $offset,
      ],
    ]);
  }

  /**
   * ==========================
   * POST: SCAN QR
   * ==========================
   * action=scan
   * code=XXXX (visitas.codigo_acceso)
   * tipo_evento=entrada|salida|verificacion (default entrada)
   * observaciones=...
   */
  if ($method === 'POST' && $action === 'scan') {

    $code = strv($_POST['code'] ?? '', 64);
    if ($code === '') out(false, ['error' => 'Falta code'], 422);

    $tipoEvento = strv($_POST['tipo_evento'] ?? 'entrada', 20);
    $allowedTipoEvento = ['entrada','salida','verificacion'];
    if (!in_array($tipoEvento, $allowedTipoEvento, true)) {
      out(false, ['error' => 'tipo_evento inválido'], 422);
    }

    $obsUser = strv($_POST['observaciones'] ?? '', 255);

    $pdo->beginTransaction();

    // Lock de la visita para evitar doble escaneo simultáneo
    $stmt = $pdo->prepare("
      SELECT v.*, u.nombre AS unidad_nombre, r.name AS residente_nombre
      FROM visitas v
      JOIN unidades u ON u.id = v.unidad_id
      JOIN users r    ON r.id = v.residente_id
      WHERE v.residencial_id = :rid AND v.codigo_acceso = :code
      LIMIT 1
      FOR UPDATE
    ");
    $stmt->execute(['rid' => $residencialId, 'code' => $code]);
    $visita = $stmt->fetch();

    if (!$visita) {
      // log denegado
      $ins = $pdo->prepare("
        INSERT INTO accesos_guardia (visita_id, guardia_id, tipo_evento, resultado, observaciones)
        VALUES (0, :gid, :tipo, 'denegado', :obs)
      ");
      $ins->execute([
        'gid' => $guardiaId,
        'tipo'=> $tipoEvento,
        'obs' => 'Código no encontrado en este residencial. ' . $obsUser,
      ]);
      $pdo->commit();
      out(false, ['error' => 'Código no encontrado o no pertenece a este residencial.'], 404);
    }

    $now = now_mx();
    $today = $now->format('Y-m-d');

    $permitido = true;
    $motivoDenegado = '';

    // Estado
    if ($visita['estado'] === 'cancelado') { $permitido = false; $motivoDenegado = 'Acceso cancelado.'; }
    if ($visita['estado'] === 'vencido')   { $permitido = false; $motivoDenegado = 'Acceso vencido.'; }
    if ($visita['estado'] === 'usado' && (int)$visita['uso_unico'] === 1) {
      $permitido = false; $motivoDenegado = 'Acceso de uso único ya utilizado.';
    }

    // Fecha
    if ($permitido) {
      if ($today < $visita['fecha_desde'] || $today > $visita['fecha_hasta']) {
        $permitido = false;
        $motivoDenegado = 'Fuera del rango de fechas permitido.';
      }
    }

    // Hora (si aplica)
    if ($permitido) {
      $hDesde = $visita['hora_desde'] ?: null;
      $hHasta = $visita['hora_hasta'] ?: null;
      if (!time_in_range($hDesde, $hHasta, $now)) {
        $permitido = false;
        $motivoDenegado = 'Fuera del horario permitido.';
      }
    }

    // Si ya venció, actualiza estado automáticamente
    if ($today > $visita['fecha_hasta'] && $visita['estado'] === 'pendiente') {
      $u = $pdo->prepare("UPDATE visitas SET estado='vencido' WHERE id=:id");
      $u->execute(['id' => (int)$visita['id']]);
      $visita['estado'] = 'vencido';
      $permitido = false;
      $motivoDenegado = 'Acceso vencido.';
    }

    // Inserta log guardia
    $resultado = $permitido ? 'permitido' : 'denegado';
    $obs = trim(($motivoDenegado ? $motivoDenegado . ' ' : '') . $obsUser);

    $ins = $pdo->prepare("
      INSERT INTO accesos_guardia (visita_id, guardia_id, tipo_evento, resultado, observaciones)
      VALUES (:vid, :gid, :tipo, :res, :obs)
    ");
    $ins->execute([
      'vid' => (int)$visita['id'],
      'gid' => $guardiaId,
      'tipo'=> $tipoEvento,
      'res' => $resultado,
      'obs' => ($obs !== '' ? $obs : null),
    ]);

    // Si permitido y es uso único => marcar usado
    if ($permitido && (int)$visita['uso_unico'] === 1) {
      $up = $pdo->prepare("UPDATE visitas SET estado='usado' WHERE id=:id");
      $up->execute(['id' => (int)$visita['id']]);
      $visita['estado'] = 'usado';
    }

    $pdo->commit();

    out(true, [
      'message' => $permitido ? 'Acceso permitido' : 'Acceso denegado',
      'permitido' => $permitido,
      'visita' => $visita,
      'resultado' => $resultado,
    ]);
  }

  out(false, ['error' => 'Acción no soportada'], 400);

} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  out(false, ['error' => 'Error: ' . $e->getMessage()], 500);
}
