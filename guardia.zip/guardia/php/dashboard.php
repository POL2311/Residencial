<?php
// guardia/php/dashboard.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/auth.php';

require_login();
require_role(['guardia', 'super_admin']);

$pageTitle  = 'Panel de guardia';
$activeMenu = 'security';

ob_start();
?>
<div id="guardiaApp">
  <?php include __DIR__ . '/../templates/dashboard.html'; ?>
</div>

<script src="../js/dashboard.js?v=1" defer></script>
<?php
$content = ob_get_clean();

include __DIR__ . '/../../layouts/dashboard_layout.php';
