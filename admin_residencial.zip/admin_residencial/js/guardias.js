(function () {
  if (window.__admin_guardias_init) return;
  window.__admin_guardias_init = true;

  function basePath() {
    const p = location.pathname;
    const i = p.indexOf('/admin_residencial/');
    return i === -1 ? '/admin_residencial/' : p.slice(0, i) + '/admin_residencial/';
  }
  const API = basePath() + 'php/api/';

  const alertBox = document.getElementById('guardiasAlert');
  const tableBody = document.getElementById('guardiasTableBody');
  const btnAdd = document.getElementById('btnAddGuardia');
  const modal = document.getElementById('guardiaModal');
  const form = document.getElementById('guardiaForm');
  const btnClose = document.getElementById('btnCloseGuardiaModal');

  let guardsData = [];

  function showAlert(msg, isError = false) {
    if (!alertBox) return;
    alertBox.textContent = msg;
    alertBox.classList.remove('hidden');
    alertBox.classList.toggle('bg-red-100', isError);
    alertBox.classList.toggle('text-red-800', isError);
    alertBox.classList.toggle('bg-green-100', !isError);
    alertBox.classList.toggle('text-green-800', !isError);
    setTimeout(() => alertBox.classList.add('hidden'), 5000);
  }

  btnAdd.addEventListener('click', () => {
    form.reset();
    modal.classList.remove('hidden');
  });

  btnClose.addEventListener('click', () => {
    modal.classList.add('hidden');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    try {
      const res = await fetch(API + 'guardias.php', { method: 'POST', body: formData, credentials: 'same-origin' });
      const json = await res.json();
      if (json.ok) {
        showAlert(json.message || 'Guardia guardado.');
        modal.classList.add('hidden');
        await loadGuards();
      } else {
        showAlert(json.error || 'Error al guardar guardia.', true);
      }
    } catch (err) {
      showAlert('Error de red al guardar guardia.', true);
    }
  });

  tableBody.addEventListener('click', async (e) => {
    if (e.target.matches('.toggle-guard')) {
      const btn = e.target;
      const guardId = btn.getAttribute('data-id');
      const newActive = btn.getAttribute('data-active') === '1' ? 0 : 1;
      try {
        const formData = new FormData();
        formData.append('action', 'toggle_active');
        formData.append('id', guardId);
        formData.append('active', newActive);
        const res = await fetch(API + 'guardias.php', { method: 'POST', body: formData, credentials: 'same-origin' });
        const json = await res.json();
        if (json.ok) {
          showAlert(json.message || 'Estado actualizado.');
          const row = btn.closest('tr');
          if (row) {
            const statusCell = row.querySelector('.status');
            statusCell.textContent = newActive ? 'Activo' : 'Inactivo';
            btn.textContent = newActive ? 'Desactivar' : 'Reactivar';
            btn.setAttribute('data-active', newActive);
          }
        } else {
          showAlert(json.error || 'Error al actualizar guardia.', true);
        }
      } catch (err) {
        showAlert('Error de red al actualizar guardia.', true);
      }
    }
  });

  function renderGuards() {
    tableBody.innerHTML = '';
    guardsData.forEach(g => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="px-3 py-2">${g.name}</td>
        <td class="px-3 py-2">${g.email}</td>
        <td class="px-3 py-2">${g.telefono || '-'}</td>
        <td class="px-3 py-2 status ${g.is_active ? 'text-green-600' : 'text-red-600'}">${g.is_active ? 'Activo' : 'Inactivo'}</td>
        <td class="px-3 py-2 text-right">
          <button class="toggle-guard text-sm text-blue-600 hover:underline" data-id="${g.id}" data-active="${g.is_active ? 1 : 0}">
            ${g.is_active ? 'Desactivar' : 'Reactivar'}
          </button>
        </td>`;
      tableBody.appendChild(tr);
    });
  }

  async function loadGuards() {
    try {
      const res = await fetch(API + 'guardias.php', { credentials: 'same-origin' });
      const json = await res.json();
      if (json.ok) {
        guardsData = json.guardias || [];
        renderGuards();
      } else {
        showAlert(json.error || 'Error al cargar guardias.', true);
      }
    } catch (err) {
      showAlert('Error de red al cargar guardias.', true);
    }
  }

  loadGuards();
})();
