(function () {
  if (window.__admin_unidades_init) return;
  window.__admin_unidades_init = true;

  function basePath() {
    const p = location.pathname;
    const i = p.indexOf('/admin_residencial/');
    return i === -1 ? '/admin_residencial/' : p.slice(0, i) + '/admin_residencial/';
  }
  const API = basePath() + 'php/api/';

  const alertBox = document.getElementById('unidadesAlert');
  const tableBody = document.getElementById('unidadesTableBody');
  const searchInput = document.getElementById('searchUnidad');
  const modal = document.getElementById('unitModal');
  const form = document.getElementById('unitForm');
  const modalTitle = document.getElementById('unitModalTitle');
  const btnAdd = document.getElementById('btnAddUnidad');
  const btnClose = document.getElementById('btnCloseUnitModal');

  let unitsData = [];

  function showAlert(message, isError = false) {
    if (!alertBox) return;
    alertBox.textContent = message;
    alertBox.classList.remove('hidden');
    alertBox.classList.toggle('bg-red-100', isError);
    alertBox.classList.toggle('text-red-800', isError);
    alertBox.classList.toggle('bg-green-100', !isError);
    alertBox.classList.toggle('text-green-800', !isError);
    setTimeout(() => alertBox.classList.add('hidden'), 5000);
  }

  function filterUnits() {
    const term = searchInput.value.toLowerCase();
    const rows = tableBody.querySelectorAll('tr');
    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      row.classList.toggle('hidden', term && !text.includes(term));
    });
  }

  searchInput.addEventListener('input', filterUnits);

  btnAdd.addEventListener('click', () => {
    form.reset();
    modalTitle.textContent = 'Nueva unidad';
    form.querySelector('[name="id"]').value = '';
    modal.classList.remove('hidden');
  });

  btnClose.addEventListener('click', () => {
    modal.classList.add('hidden');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    try {
      const res = await fetch(API + 'unidades.php', { method: 'POST', body: formData, credentials: 'same-origin' });
      const json = await res.json();
      if (json.ok) {
        showAlert(json.message || 'Guardado exitosamente.');
        modal.classList.add('hidden');
        await loadUnits();
      } else {
        showAlert(json.error || 'Error al guardar la unidad.', true);
      }
    } catch (err) {
      showAlert('Error de red al guardar.', true);
    }
  });

  tableBody.addEventListener('click', async (e) => {
    const target = e.target;
    if (target.matches('.btn-edit-unit')) {
      // Editar unidad
      const uid = target.getAttribute('data-id');
      const unit = unitsData.find(u => u.id == uid);
      if (!unit) return;
      form.reset();
      modalTitle.textContent = 'Editar unidad';
      form.querySelector('[name="id"]').value = unit.id;
      form.querySelector('[name="tipo"]').value = unit.tipo;
      form.querySelector('[name="clave"]').value = unit.clave;
      form.querySelector('[name="calle"]').value = unit.calle || '';
      form.querySelector('[name="numero_exterior"]').value = unit.numero_exterior || '';
      form.querySelector('[name="numero_interior"]').value = unit.numero_interior || '';
      form.querySelector('[name="torre"]').value = unit.torre || '';
      form.querySelector('[name="nivel"]').value = unit.nivel || '';
      form.querySelector('[name="notas"]').value = unit.notas || '';
      modal.classList.remove('hidden');
    }
    if (target.matches('.btn-delete-unit')) {
      const uid = target.getAttribute('data-id');
      if (!confirm('¿Eliminar unidad?')) return;
      try {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', uid);
        const res = await fetch(API + 'unidades.php', { method: 'POST', body: formData, credentials: 'same-origin' });
        const json = await res.json();
        if (json.ok) {
          showAlert(json.message || 'Unidad eliminada.');
          await loadUnits();
        } else {
          showAlert(json.error || 'Error al eliminar unidad.', true);
        }
      } catch (err) {
        showAlert('Error de red al eliminar.', true);
      }
    }
  });

  function renderUnits() {
    tableBody.innerHTML = '';
    unitsData.forEach(u => {
      const address = u.calle ? `${u.calle} ${u.numero_exterior || ''}${u.numero_interior ? ' Int. ' + u.numero_interior : ''}` :
                     u.torre ? `Torre ${u.torre}${u.nivel ? ', Nivel ' + u.nivel : ''}` : '';
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="px-3 py-2">${u.clave}</td>
        <td class="px-3 py-2">${u.tipo.charAt(0).toUpperCase() + u.tipo.slice(1)}</td>
        <td class="px-3 py-2">${address || '-'}</td>
        <td class="px-3 py-2">${u.notas || ''}</td>
        <td class="px-3 py-2 ${u.activo ? 'text-green-600' : 'text-red-600'}">${u.activo ? 'Activa' : 'Inactiva'}</td>
        <td class="px-3 py-2 text-right">
          <button class="btn-edit-unit text-sm text-blue-600 hover:underline mr-3" data-id="${u.id}">Editar</button>
          <button class="btn-delete-unit text-sm text-red-600 hover:underline" data-id="${u.id}">Eliminar</button>
        </td>`;
      tableBody.appendChild(tr);
    });
  }

  async function loadUnits() {
    try {
      const res = await fetch(API + 'unidades.php', { credentials: 'same-origin' });
      const json = await res.json();
      if (json.ok) {
        unitsData = json.unidades || [];
        renderUnits();
        filterUnits();
      } else {
        showAlert(json.error || 'Error al cargar unidades.', true);
      }
    } catch (err) {
      showAlert('Error de red al cargar unidades.', true);
    }
  }

  loadUnits();
})();
