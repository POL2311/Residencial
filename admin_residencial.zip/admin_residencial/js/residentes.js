(function () {
  if (window.__admin_residentes_init) return;
  window.__admin_residentes_init = true;

  function basePath() {
    const p = location.pathname;
    const i = p.indexOf('/admin_residencial/');
    return i === -1 ? '/admin_residencial/' : p.slice(0, i) + '/admin_residencial/';
  }
  const API = basePath() + 'php/api/';

  const alertBox = document.getElementById('residentesAlert');
  const tableBody = document.getElementById('residentesTableBody');
  const searchInput = document.getElementById('searchResident');
  const modal = document.getElementById('addResidentModal');
  const form = document.getElementById('addResidentForm');
  const btnAdd = document.getElementById('btnAddResidente');
  const btnCloseModal = document.getElementById('btnCloseAddResident');

  let residentsData = [];
  let unitsData = [];

  function showAlert(message, isError = false) {
    if (!alertBox) return;
    alertBox.textContent = message;
    alertBox.classList.remove('hidden');
    alertBox.classList.toggle('bg-red-100', isError);
    alertBox.classList.toggle('text-red-800', isError);
    alertBox.classList.toggle('bg-green-100', !isError);
    alertBox.classList.toggle('text-green-800', !isError);
    setTimeout(() => {
      alertBox.classList.add('hidden');
    }, 5000);
  }

  // Filtrar tabla por nombre/contacto
  function filterResidents() {
    const term = searchInput.value.toLowerCase();
    const rows = tableBody.querySelectorAll('tr');
    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      row.classList.toggle('hidden', term && !text.includes(term));
    });
  }

  searchInput.addEventListener('input', filterResidents);

  btnAdd.addEventListener('click', () => {
    form.reset();
    // Llenar opciones de unidades
    const unitSelect = form.querySelector('select[name="unidad_id"]');
    unitSelect.innerHTML = '';
    unitsData.forEach(u => {
      const optionText = u.calle ? `${u.calle} ${u.numero_exterior || ''}`.trim() + (u.numero_interior ? ` Int. ${u.numero_interior}` : '') :
                        u.torre ? `Torre ${u.torre}${u.nivel ? ' Nivel ' + u.nivel : ''} - ${u.clave}` : 
                        u.clave;
      const opt = document.createElement('option');
      opt.value = u.id;
      opt.textContent = optionText;
      unitSelect.appendChild(opt);
    });
    modal.classList.remove('hidden');
  });

  btnCloseModal.addEventListener('click', () => {
    modal.classList.add('hidden');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    try {
      const res = await fetch(API + 'residentes.php', { method: 'POST', body: formData, credentials: 'same-origin' });
      const json = await res.json();
      if (!json.ok) {
        showAlert(json.error || 'Error al guardar el residente.', true);
      } else {
        showAlert(json.message || 'Residente agregado exitosamente.');
        modal.classList.add('hidden');
        await loadResidents();
      }
    } catch (err) {
      showAlert('Error de red al guardar residente.', true);
    }
  });

  tableBody.addEventListener('click', async (e) => {
    if (e.target.matches('.toggle-resident')) {
      const btn = e.target;
      const residUnidId = btn.getAttribute('data-id');
      const newActive = btn.getAttribute('data-active') === '1' ? 0 : 1;
      try {
        const formData = new FormData();
        formData.append('action', 'toggle_active');
        formData.append('id', residUnidId);
        formData.append('active', newActive);
        const res = await fetch(API + 'residentes.php', { method: 'POST', body: formData, credentials: 'same-origin' });
        const json = await res.json();
        if (json.ok) {
          showAlert(json.message || 'Estado actualizado.');
          const row = btn.closest('tr');
          if (row) {
            const statusCell = row.querySelector('td.status');
            if (statusCell) {
              statusCell.textContent = newActive ? 'Activo' : 'Suspendido';
            }
            btn.textContent = newActive ? 'Suspender' : 'Reactivar';
            btn.setAttribute('data-active', newActive);
          }
        } else {
          showAlert(json.error || 'Error al actualizar estado.', true);
        }
      } catch (err) {
        showAlert('Error de red al actualizar estado.', true);
      }
    }
  });

  function renderResidents() {
    tableBody.innerHTML = '';
    residentsData.forEach(res => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="px-3 py-2">${res.name}</td>
        <td class="px-3 py-2">
          ${res.calle ? `${res.calle} ${res.numero_exterior || ''}${res.numero_interior ? ' Int. ' + res.numero_interior : ''}` :
             res.torre ? `Torre ${res.torre}${res.nivel ? ', Nivel ' + res.nivel : ''}, ${res.clave}` :
             res.clave}
        </td>
        <td class="px-3 py-2 status ${res.activo_servicio ? 'text-green-600' : 'text-red-600'}">
          ${res.activo_servicio ? 'Activo' : 'Suspendido'}
        </td>
        <td class="px-3 py-2">${res.telefono || res.email}</td>
        <td class="px-3 py-2 text-right">
          <button class="toggle-resident text-sm text-blue-600 hover:underline" data-id="${res.resid_unid_id}" data-active="${res.activo_servicio ? 1 : 0}">
            ${res.activo_servicio ? 'Suspender' : 'Reactivar'}
          </button>
        </td>`;
      tableBody.appendChild(tr);
    });
  }

  async function loadResidents() {
    try {
      const res = await fetch(API + 'residentes.php', { credentials: 'same-origin' });
      const json = await res.json();
      if (!json.ok) {
        showAlert(json.error || 'No se pudieron cargar los residentes.', true);
        return;
      }
      residentsData = json.residentes || [];
      renderResidents();
      filterResidents();
    } catch (err) {
      showAlert('Error de red al cargar residentes.', true);
    }
  }

  // Cargar unidades y residentes al inicializar
  (async function init() {
    try {
      const resUnits = await fetch(API + 'unidades.php', { credentials: 'same-origin' });
      const jsonUnits = await resUnits.json();
      if (jsonUnits.ok) {
        unitsData = jsonUnits.unidades || [];
      }
    } catch (e) {
      console.error('No se pudo cargar la lista de unidades.');
    }
    loadResidents();
  })();
})();
