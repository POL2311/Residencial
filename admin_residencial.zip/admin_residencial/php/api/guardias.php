<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/../../../config/auth.php';
require_once __DIR__ . '/../../../config/config.php';

require_login();
require_role(['admin_residencial']);

$user = current_user();
$adminId = (int)($user['id'] ?? 0);

try {
    $stmtRes = $pdo->prepare("SELECT residencial_id FROM usuarios_residenciales WHERE user_id = ? ORDER BY es_principal DESC LIMIT 1");
    $stmtRes->execute([$adminId]);
    $residencialId = (int)$stmtRes->fetchColumn();
    if (!$residencialId) {
        echo json_encode(['ok' => false, 'error' => 'No tienes un residencial asignado.']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['ok' => false, 'error' => 'Error al obtener residencial.']);
    exit;
}

function json_out(bool $ok, array $data = []) {
    echo json_encode(array_merge(['ok' => $ok], $data));
    exit;
}

// GET: listar guardias
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare("SELECT u.id, u.name, u.email, u.telefono, u.is_active
                               FROM usuarios_residenciales ur
                               JOIN users u ON u.id = ur.user_id
                               WHERE ur.residencial_id = ? AND u.tipo_usuario_id = 4");
        $stmt->execute([$residencialId]);
        $guardias = $stmt->fetchAll(PDO::FETCH_ASSOC);
        json_out(true, ['guardias' => $guardias]);
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al obtener guardias.']);
    }
}

// POST: agregar guardia o cambiar estado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Activar/desactivar guardia
    if (isset($_POST['action']) && $_POST['action'] === 'toggle_active') {
        $guardId = (int)($_POST['id'] ?? 0);
        $newStatus = isset($_POST['active']) ? (int)$_POST['active'] : 0;
        try {
            $stmt = $pdo->prepare("UPDATE users u 
                                   JOIN usuarios_residenciales ur ON u.id = ur.user_id
                                   SET u.is_active = :active
                                   WHERE u.id = :uid AND ur.residencial_id = :resid AND u.tipo_usuario_id = 4");
            $stmt->execute(['active' => $newStatus, 'uid' => $guardId, 'resid' => $residencialId]);
            if ($stmt->rowCount() === 0) {
                json_out(false, ['error' => 'Guardia no encontrado o fuera de tu residencial.']);
            }
            json_out(true, ['message' => $newStatus ? 'Guardia activado.' : 'Guardia desactivado.']);
        } catch (PDOException $e) {
            json_out(false, ['error' => 'Error al actualizar guardia.']);
        }
    }

    // Agregar nuevo guardia
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = preg_replace('/\D+/', '', $_POST['telefono'] ?? '');
    if ($name === '' || $email === '') {
        json_out(false, ['error' => 'Nombre y email son requeridos.']);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_out(false, ['error' => 'Correo inválido.']);
    }
    try {
        // Verificar email no usado
        $stmtCheck = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmtCheck->execute([$email]);
        if ($stmtCheck->fetchColumn()) {
            json_out(false, ['error' => 'El correo ya está registrado.']);
        }
        // Crear usuario guardia
        function generate_password($length = 8) {
            $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
            $pass = '';
            for ($i = 0; $i < $length; $i++) {
                $pass .= $chars[random_int(0, strlen($chars) - 1)];
            }
            return $pass;
        }
        $plainPassword = generate_password(8);
        $passwordHash = password_hash($plainPassword, PASSWORD_DEFAULT);
        $stmtIns = $pdo->prepare("INSERT INTO users (tipo_usuario_id, name, email, telefono, password_hash, is_active) 
                                  VALUES (4, :name, :email, :tel, :pass, 1)");
        $stmtIns->execute(['name' => $name, 'email' => $email, 'tel' => $phone, 'pass' => $passwordHash]);
        $newUserId = (int)$pdo->lastInsertId();
        // Vincular guardia al residencial
        $stmtLink = $pdo->prepare("INSERT INTO usuarios_residenciales (user_id, residencial_id, es_principal) VALUES (?, ?, 1)");
        $stmtLink->execute([$newUserId, $residencialId]);
        json_out(true, ['message' => 'Guardia agregado correctamente. Contraseña temporal: ' . $plainPassword]);
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al agregar guardia.']);
    }
}
?>
