<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/../../../config/auth.php';
require_once __DIR__ . '/../../../config/config.php';

require_login();
require_role(['admin_residencial']);

$user = current_user();
$adminId = (int)($user['id'] ?? 0);

try {
    $stmtRes = $pdo->prepare("SELECT residencial_id FROM usuarios_residenciales WHERE user_id = ? ORDER BY es_principal DESC LIMIT 1");
    $stmtRes->execute([$adminId]);
    $residencialId = (int)$stmtRes->fetchColumn();
    if (!$residencialId) {
        echo json_encode(['ok' => false, 'error' => 'No tienes un residencial asignado.']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['ok' => false, 'error' => 'Error al obtener residencial.']);
    exit;
}

function json_out(bool $ok, array $data = []) {
    echo json_encode(array_merge(['ok' => $ok], $data));
    exit;
}

// GET: listar unidades del residencial
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare("SELECT id, tipo, clave, calle, numero_exterior, numero_interior, torre, nivel, notas, activo 
                               FROM unidades 
                               WHERE residencial_id = ? 
                               ORDER BY clave ASC");
        $stmt->execute([$residencialId]);
        $unidades = $stmt->fetchAll(PDO::FETCH_ASSOC);
        json_out(true, ['unidades' => $unidades]);
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al obtener unidades.']);
    }
}

// POST: crear, editar o eliminar unidad
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Eliminar unidad (opcional)
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $unitId = (int)($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM unidades WHERE id = ? AND residencial_id = ?");
            $stmt->execute([$unitId, $residencialId]);
            if ($stmt->rowCount() === 0) {
                json_out(false, ['error' => 'Unidad no encontrada o no eliminada.']);
            }
            json_out(true, ['message' => 'Unidad eliminada.']);
        } catch (PDOException $e) {
            json_out(false, ['error' => 'Error al eliminar la unidad.']);
        }
    }

    // Agregar o actualizar unidad
    $unitId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $tipo   = $_POST['tipo'] ?? '';
    $clave  = trim($_POST['clave'] ?? '');
    $calle  = trim($_POST['calle'] ?? '');
    $numExt = trim($_POST['numero_exterior'] ?? '');
    $numInt = trim($_POST['numero_interior'] ?? '');
    $torre  = trim($_POST['torre'] ?? '');
    $nivel  = trim($_POST['nivel'] ?? '');
    $notas  = trim($_POST['notas'] ?? '');
    if ($tipo === '' || $clave === '') {
        json_out(false, ['error' => 'Tipo y clave son requeridos.']);
    }
    try {
        if ($unitId > 0) {
            // Actualizar unidad existente
            $stmtUp = $pdo->prepare("UPDATE unidades 
                                     SET tipo = :tipo, clave = :clave, calle = :calle, numero_exterior = :numExt, numero_interior = :numInt, torre = :torre, nivel = :nivel, notas = :notas 
                                     WHERE id = :id AND residencial_id = :resid");
            $stmtUp->execute([
                'tipo' => $tipo, 'clave' => $clave, 'calle' => $calle, 
                'numExt' => $numExt, 'numInt' => $numInt, 'torre' => $torre, 'nivel' => $nivel, 'notas' => $notas,
                'id' => $unitId, 'resid' => $residencialId
            ]);
            if ($stmtUp->rowCount() === 0) {
                json_out(false, ['error' => 'No se pudo actualizar la unidad.']);
            }
            json_out(true, ['message' => 'Unidad actualizada correctamente.']);
        } else {
            // Verificar clave única en residencial
            $stmtChk = $pdo->prepare("SELECT id FROM unidades WHERE residencial_id = ? AND clave = ? LIMIT 1");
            $stmtChk->execute([$residencialId, $clave]);
            if ($stmtChk->fetchColumn()) {
                json_out(false, ['error' => 'Ya existe una unidad con esa clave.']);
            }
            // Insertar nueva unidad
            $stmtIns = $pdo->prepare("INSERT INTO unidades (residencial_id, tipo, clave, calle, numero_exterior, numero_interior, torre, nivel, notas, activo, created_at) 
                                      VALUES (:resid, :tipo, :clave, :calle, :numExt, :numInt, :torre, :nivel, :notas, 1, NOW())");
            $stmtIns->execute([
                'resid' => $residencialId, 'tipo' => $tipo, 'clave' => $clave, 'calle' => $calle,
                'numExt' => $numExt, 'numInt' => $numInt, 'torre' => $torre, 'nivel' => $nivel, 'notas' => $notas
            ]);
            json_out(true, ['message' => 'Unidad agregada correctamente.']);
        }
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al guardar la unidad.']);
    }
}
?>
