<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/../../../config/auth.php';
require_once __DIR__ . '/../../../config/config.php';

require_login();
require_role(['admin_residencial']);

$user = current_user();
$adminId = (int)($user['id'] ?? 0);

// Obtener ID del residencial asignado al admin actual
try {
    $stmtRes = $pdo->prepare("SELECT residencial_id FROM usuarios_residenciales WHERE user_id = ? ORDER BY es_principal DESC LIMIT 1");
    $stmtRes->execute([$adminId]);
    $residencialId = (int)$stmtRes->fetchColumn();
    if (!$residencialId) {
        echo json_encode(['ok' => false, 'error' => 'No tienes residencial asignado.']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['ok' => false, 'error' => 'Error al obtener el residencial.']);
    exit;
}

// Helper para respuesta JSON
function json_out(bool $ok, array $data = []) {
    echo json_encode(array_merge(['ok' => $ok], $data));
    exit;
}

// GET: listar residentes del residencial
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $sql = "SELECT u.id AS user_id, u.name, u.email, u.telefono, u.is_active, 
                       ru.id AS resid_unid_id, ru.es_titular, ru.activo AS activo_servicio,
                       un.id AS unidad_id, un.clave, un.calle, un.numero_exterior, un.numero_interior, un.torre, un.nivel
                FROM usuarios_residenciales ur
                JOIN users u ON u.id = ur.user_id
                JOIN tipos_usuario t ON t.id = u.tipo_usuario_id
                JOIN residentes_unidades ru ON ru.user_id = u.id
                JOIN unidades un ON un.id = ru.unidad_id
                WHERE ur.residencial_id = :resid AND t.nombre = 'residente'
                ORDER BY un.clave ASC, u.name ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['resid' => $residencialId]);
        $residentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        json_out(true, ['residentes' => $residentes]);
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al obtener residentes.']);
    }
}

// POST: agregar nuevo residente o actualizar estado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Suspender o reactivar residente
    if (isset($_POST['action']) && $_POST['action'] === 'toggle_active') {
        $residUnitId = (int)($_POST['id'] ?? 0);
        $newStatus = isset($_POST['active']) ? (int)$_POST['active'] : 0;
        try {
            $stmt = $pdo->prepare("UPDATE residentes_unidades ru 
                                   JOIN unidades un ON un.id = ru.unidad_id
                                   SET ru.activo = :act 
                                   WHERE ru.id = :ru_id AND un.residencial_id = :resid");
            $stmt->execute(['act' => $newStatus, 'ru_id' => $residUnitId, 'resid' => $residencialId]);
            if ($stmt->rowCount() === 0) {
                json_out(false, ['error' => 'Residente no encontrado o fuera de tu residencial.']);
            }
            $msg = $newStatus ? 'Residente reactivado.' : 'Residente suspendido.';
            json_out(true, ['message' => $msg]);
        } catch (PDOException $e) {
            json_out(false, ['error' => 'Error al actualizar estado del residente.']);
        }
    }

    // Agregar nuevo residente
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = preg_replace('/\D+/', '', $_POST['telefono'] ?? '');
    $unitId  = (int)($_POST['unidad_id'] ?? 0);
    $isTitular = isset($_POST['es_titular']) ? 1 : 0;
    if ($name === '' || $email === '' || $unitId <= 0) {
        json_out(false, ['error' => 'Nombre, email y unidad son requeridos.']);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_out(false, ['error' => 'Correo electrónico inválido.']);
    }
    try {
        // Verificar unidad pertenece al residencial
        $stmtU = $pdo->prepare("SELECT id FROM unidades WHERE id = :uid AND residencial_id = :resid AND activo = 1");
        $stmtU->execute(['uid' => $unitId, 'resid' => $residencialId]);
        if (!$stmtU->fetchColumn()) {
            json_out(false, ['error' => 'Unidad no válida en este residencial.']);
        }
        // Verificar email único
        $stmtCheck = $pdo->prepare("SELECT u.id, u.tipo_usuario_id FROM users u WHERE u.email = :email LIMIT 1");
        $stmtCheck->execute(['email' => $email]);
        $existing = $stmtCheck->fetch(PDO::FETCH_ASSOC);
        if ($existing) {
            $userIdExisting = (int)$existing['id'];
            $stmtExistsRes = $pdo->prepare("SELECT id FROM usuarios_residenciales WHERE user_id = ? AND residencial_id = ?");
            $stmtExistsRes->execute([$userIdExisting, $residencialId]);
            if ($stmtExistsRes->fetchColumn()) {
                json_out(false, ['error' => 'Ya existe un residente con este correo en el residencial.']);
            }
            if ((int)$existing['tipo_usuario_id'] !== 5) {
                json_out(false, ['error' => 'El correo proporcionado ya está en uso por otro usuario.']);
            }
            // Usuario existe (residente en otro residencial), usamos ese usuario
            $newUserId = $userIdExisting;
        } else {
            // Crear nuevo usuario residente
            function generate_password($length = 8) {
                $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
                $pass = '';
                for ($i = 0; $i < $length; $i++) {
                    $pass .= $chars[random_int(0, strlen($chars) - 1)];
                }
                return $pass;
            }
            $plainPassword = generate_password(8);
            $passwordHash = password_hash($plainPassword, PASSWORD_DEFAULT);
            $stmtNewU = $pdo->prepare("INSERT INTO users (tipo_usuario_id, name, email, telefono, password_hash, is_active) 
                                       VALUES (5, :name, :email, :tel, :pass, 1)");
            $stmtNewU->execute(['name' => $name, 'email' => $email, 'tel' => $phone, 'pass' => $passwordHash]);
            $newUserId = (int)$pdo->lastInsertId();
        }
        // Asignar usuario al residencial
        $stmtLinkRes = $pdo->prepare("INSERT IGNORE INTO usuarios_residenciales (user_id, residencial_id, es_principal) VALUES (?, ?, 1)");
        $stmtLinkRes->execute([$newUserId, $residencialId]);
        // Asignar usuario a la unidad
        $stmtLinkUnit = $pdo->prepare("INSERT INTO residentes_unidades (user_id, unidad_id, es_titular, activo) VALUES (?, ?, ?, 1)");
        $stmtLinkUnit->execute([$newUserId, $unitId, $isTitular]);
        $msgExtra = isset($plainPassword) ? " Contraseña temporal: $plainPassword" : "";
        json_out(true, ['message' => 'Residente agregado correctamente.' . $msgExtra]);
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al agregar residente.']);
    }
}
?>
