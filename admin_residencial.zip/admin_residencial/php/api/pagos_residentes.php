<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/../../../config/auth.php';
require_once __DIR__ . '/../../../config/config.php';

require_login();
require_role(['admin_residencial']);

$user = current_user();
$adminId = (int)($user['id'] ?? 0);
try {
    $stmtRes = $pdo->prepare("SELECT residencial_id FROM usuarios_residenciales WHERE user_id = ? ORDER BY es_principal DESC LIMIT 1");
    $stmtRes->execute([$adminId]);
    $residencialId = (int)$stmtRes->fetchColumn();
    if (!$residencialId) {
        echo json_encode(['ok' => false, 'error' => 'No tienes un residencial asignado.']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['ok' => false, 'error' => 'Error al obtener residencial.']);
    exit;
}

function json_out(bool $ok, array $data = []) {
    echo json_encode(array_merge(['ok' => $ok], $data));
    exit;
}

// GET: listar pagos
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare("SELECT p.id, p.monto, p.fecha_pago, p.metodo, p.concepto, u.name AS residente_nombre, un.clave AS unidad_clave
                               FROM pagos_residentes p
                               JOIN users u ON u.id = p.user_id
                               JOIN usuarios_residenciales ur ON ur.user_id = u.id
                               JOIN residentes_unidades ru ON ru.user_id = u.id
                               JOIN unidades un ON un.id = ru.unidad_id
                               WHERE p.residencial_id = ? 
                               ORDER BY p.fecha_pago DESC, p.id DESC");
        $stmt->execute([$residencialId]);
        $pagos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        json_out(true, ['pagos' => $pagos]);
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al obtener pagos.']);
    }
}

// POST: agregar, editar o eliminar pago
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Eliminar pago
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $pagoId = (int)($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM pagos_residentes WHERE id = ? AND residencial_id = ?");
            $stmt->execute([$pagoId, $residencialId]);
            if ($stmt->rowCount() === 0) {
                json_out(false, ['error' => 'Pago no encontrado o no eliminado.']);
            }
            json_out(true, ['message' => 'Pago eliminado.']);
        } catch (PDOException $e) {
            json_out(false, ['error' => 'Error al eliminar pago.']);
        }
    }

    // Agregar o editar pago
    $pagoId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $userId = (int)($_POST['user_id'] ?? 0);
    $monto = isset($_POST['monto']) ? (float)$_POST['monto'] : 0;
    $fechaPago = $_POST['fecha_pago'] ?? '';
    $metodo = trim($_POST['metodo'] ?? '');
    $concepto = trim($_POST['concepto'] ?? '');
    if ($userId <= 0 || $monto <= 0 || $fechaPago === '' || $metodo === '') {
        json_out(false, ['error' => 'Usuario, monto, fecha y método son requeridos.']);
    }
    try {
        // Verificar que el usuario corresponde al residencial
        $stmtChk = $pdo->prepare("SELECT ur.id FROM usuarios_residenciales ur WHERE ur.user_id = ? AND ur.residencial_id = ?");
        $stmtChk->execute([$userId, $residencialId]);
        if (!$stmtChk->fetchColumn()) {
            json_out(false, ['error' => 'El usuario no pertenece a este residencial.']);
        }
        if ($pagoId > 0) {
            // Actualizar pago existente
            $stmtUp = $pdo->prepare("UPDATE pagos_residentes 
                                     SET user_id = :user, monto = :monto, fecha_pago = :fecha, metodo = :metodo, concepto = :concepto
                                     WHERE id = :id AND residencial_id = :resid");
            $stmtUp->execute([
                'user' => $userId, 'monto' => $monto, 'fecha' => $fechaPago,
                'metodo' => $metodo, 'concepto' => $concepto,
                'id' => $pagoId, 'resid' => $residencialId
            ]);
            json_out(true, ['message' => 'Pago actualizado.']);
        } else {
            // Insertar nuevo pago
            $stmtIns = $pdo->prepare("INSERT INTO pagos_residentes (residencial_id, user_id, monto, fecha_pago, metodo, concepto, created_at)
                                      VALUES (:resid, :user, :monto, :fecha, :metodo, :concepto, NOW())");
            $stmtIns->execute([
                'resid' => $residencialId, 'user' => $userId, 'monto' => $monto,
                'fecha' => $fechaPago, 'metodo' => $metodo, 'concepto' => $concepto
            ]);
            json_out(true, ['message' => 'Pago registrado.']);
        }
    } catch (PDOException $e) {
        json_out(false, ['error' => 'Error al guardar pago.']);
    }
}
?>
